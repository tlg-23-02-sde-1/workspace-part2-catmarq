package com.flashlight;

public enum FlashlightTypes {
    EVERBRITE, XHP90, STREAMLIGHT, LIFEGEAR, ENERGIZER;
}